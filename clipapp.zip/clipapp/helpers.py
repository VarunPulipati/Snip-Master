from logging import root
from tkinter import messagebox

clipboard_slots = {}  # Slots for clipboard content
clipboard_history = []
def keep_on_screen(window):
    """Ensure the window stays on screen."""
    screen_width, screen_height = window.winfo_screenwidth(), window.winfo_screenheight()
    x = max(0, min(window.winfo_x(), screen_width - window.winfo_width()))
    y = max(0, min(window.winfo_y(), screen_height - window.winfo_height()))
    window.geometry(f"+{x}+{y}")


def minimize_to_icon(window, root):
    """Minimize the main window to an icon."""
    window.withdraw()
    root.deiconify()

def search_function(query):
    """Perform a search and highlight the result in clipboard slots."""
    if query in clipboard_slots:
        messagebox.showinfo("Search Result", f"Slot {query}: {clipboard_slots[query]}")
    else:
        messagebox.showwarning("Search", "No such slot found!")

def on_drag_start(event):
    """Capture the initial position when the drag starts."""
    event.widget._drag_data = {"x": event.x, "y": event.y}

def on_drag_motion(event):
    """Handle the movement while dragging."""
    x = root.winfo_x() + event.x - event.widget._drag_data["x"]
    y = root.winfo_y() + event.y - event.widget._drag_data["y"]
    root.geometry(f"+{x}+{y}")


