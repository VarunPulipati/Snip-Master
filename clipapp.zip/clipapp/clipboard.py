from logging import root
import threading
import time
from tkinter import messagebox
import keyboard
import pyperclip

clipboard_slots = {}  # Slots for clipboard content
clipboard_history = []
valid_identifiers = [chr(i) for i in range(97, 123)]  # 'a' to 'z'

def clear_clipboard():
    """Clear the system clipboard and show a message."""
    root.clipboard_clear()
    messagebox.showinfo("Clipboard", "Clipboard cleared!")
    clipboard_history.append("Cleared Clipboard")
    clipboard_slots.clear()

def handle_copy(identifier):
    from gui import refresh_clipboard_window
    from slots import assign_default_slot
    print(f"Copy command triggered with identifier {identifier}")
    global clipboard_slots

    # Use threading to avoid blocking main execution
    def copy_content():
        time.sleep(0.1)  # Ensure clipboard updates first
        content = pyperclip.paste()  # Fetch the latest clipboard content

        if content.strip():  # Ensure valid content
            if identifier:
                clipboard_slots[identifier] = content
                #clipboard_history.append(f"Slot {identifier}: {content}")
            else:
                assign_default_slot(content)
            
            # Refresh the clipboard window if open
            if hasattr(root, 'new_window') and root.new_window.winfo_exists():
                refresh_clipboard_window(root.new_window)
        else:
            print("No valid content copied.")
    
    threading.Thread(target=copy_content).start()

def handle_cut(identifier):
    from gui import refresh_clipboard_window
    from slots import assign_default_slot
    print(f"Cut command triggered with identifier {identifier}")
    global clipboard_slots
    keyboard.press_and_release('ctrl+x')  # Perform a system cut
    time.sleep(0.2)
    content = pyperclip.paste()
    pyperclip.copy('')  # Clear clipboard
    if content.strip():
        if identifier:
            clipboard_slots[identifier] = content
            #clipboard_history.append(f"Slot {identifier}: {content} (cut)")
        else:
            threading.Thread(target=assign_default_slot, args=(content,)).start()
        if hasattr(root, 'new_window') and root.new_window.winfo_exists():
            refresh_clipboard_window(root.new_window)

def handle_paste(identifier):
    print(f"Paste command triggered with identifier {identifier}")
    text = clipboard_slots.get(identifier, '')
    if text:
        pyperclip.copy(text)
        keyboard.write(text)  # Simulate keyboard paste

def rewrite_content(identifier):
    """Rewrite the content in the slot."""
    new_content = messagebox.askstring("Rewrite", "Enter new content:")
    if new_content:
        clipboard_slots[identifier] = new_content
        messagebox.showinfo("Rewrite", f"Slot {identifier} updated.")

def rephrase_content(identifier):
    """Rephrase the content in the slot."""
    content = clipboard_slots.get(identifier, "")
    if content:
        rephrased = f"(Rephrased) {content}"  # Placeholder rephrased content
        clipboard_slots[identifier] = rephrased
        messagebox.showinfo("Rephrase", f"Slot {identifier} rephrased.")

def assign_slot(identifier):
    """Assign content to the slot."""
    new_content = messagebox.askstring("Assign", "Enter new content to assign:")
    if new_content:
        clipboard_slots[identifier] = new_content
        messagebox.showinfo("Assign", f"Slot {identifier} assigned.")

def setup_shortcuts():
    for identifier in valid_identifiers:
        keyboard.add_hotkey(f'ctrl+c+{identifier}', lambda i=identifier: handle_copy(i))
        keyboard.add_hotkey(f'ctrl+alt+v+{identifier}', lambda i=identifier: handle_paste(i))
        keyboard.add_hotkey(f'ctrl+x+{identifier}', lambda i=identifier: handle_cut(i))
    keyboard.add_hotkey('ctrl+c', lambda: handle_copy(None))
    keyboard.add_hotkey('ctrl+x', lambda: handle_cut(None))