from logging import root
from tkinter import Menu, messagebox
#from gui import *

def delete_slot(identifier):
    from tkinter import messagebox
    from clipboard import clipboard_slots
    from gui import refresh_clipboard_window, root
    if identifier in clipboard_slots:
        del clipboard_slots[identifier]
        messagebox.showinfo("Delete", f"Slot {identifier} deleted.")
        if hasattr(root, 'new_window') and root.new_window.winfo_exists():
            refresh_clipboard_window(root.new_window)
    else:
        messagebox.showwarning("Delete", f"Slot {identifier} does not exist.")

def assign_default_slot(content):
    from clipboard import clipboard_slots, clipboard_history
    from tkinter import messagebox
    for i in range(1, 10):
        if str(i) not in clipboard_slots:
            clipboard_slots[str(i)] = content
            clipboard_history.append(f"Default Slot {i}: {content}")
            return
    messagebox.showwarning("Clipboard", "No available default slots")

def show_context_menu(event, options):
    """Display a context menu with provided options."""
    menu = Menu(root, tearoff=0)
    for label, command in options:
        menu.add_command(label=label, command=command)
    menu.post(event.x_root, event.y_root)

def edit_slot(identifier):
    from clipboard import clipboard_slots, clipboard_history
    """Edit the slot name."""
    if identifier in clipboard_slots:
        new_name = messagebox.askstring("Edit Slot", f"Enter new name for Slot {identifier}:")
        if new_name and new_name not in clipboard_slots:
            clipboard_slots[new_name] = clipboard_slots.pop(identifier)
            messagebox.showinfo("Edit Slot", f"Slot {identifier} renamed to {new_name}.")
        elif new_name in clipboard_slots:
            messagebox.showwarning("Edit Slot", f"Slot name {new_name} already exists.")
    else:
        messagebox.showwarning("Edit Slot", f"Slot {identifier} does not exist.")